/* ============================================
   CAROUSEL FUNCTIONALITY
   ============================================ */

let currentSlide = 0;
const slides = document.querySelectorAll('.carousel-slide');
const indicators = document.querySelectorAll('.indicator');

function showSlide(n) {
    slides.forEach((slide, index) => {
        slide.classList.remove('active');
        indicators[index].classList.remove('active');
    });

    if (n >= slides.length) {
        currentSlide = 0;
    } else if (n < 0) {
        currentSlide = slides.length - 1;
    } else {
        currentSlide = n;
    }

    slides[currentSlide].classList.add('active');
    indicators[currentSlide].classList.add('active');
}

function nextSlide() {
    showSlide(currentSlide + 1);
}

function prevSlide() {
    showSlide(currentSlide - 1);
}

// Carousel controls
document.getElementById('nextSlide').addEventListener('click', nextSlide);
document.getElementById('prevSlide').addEventListener('click', prevSlide);

// Indicators
indicators.forEach((indicator, index) => {
    indicator.addEventListener('click', () => showSlide(index));
});

// Auto-advance carousel
setInterval(nextSlide, 5000);

/* ============================================
   BOOKING FORM FUNCTIONALITY
   ============================================ */

const bookingForm = document.getElementById('bookingForm');
const checkInInput = document.getElementById('checkIn');
const checkOutInput = document.getElementById('checkOut');
const guestsSelect = document.getElementById('guests');
const roomTypeSelect = document.getElementById('roomType');
const totalPriceDisplay = document.getElementById('totalPrice');
const progressSteps = document.querySelectorAll('.progress-step');

// Room prices
const roomPrices = {
    standard: 150,
    deluxe: 250,
    suite: 450,
    penthouse: 1000
};

// Update progress steps
function updateProgress(step) {
    progressSteps.forEach((el, index) => {
        el.classList.remove('active');
        if (index <= step) {
            el.classList.add('active');
        }
    });

    document.querySelectorAll('.progress-line').forEach((line, index) => {
        line.classList.remove('active');
        if (index < step) {
            line.classList.add('active');
        }
    });
}

// Calculate total price
function calculatePrice() {
    const checkIn = new Date(checkInInput.value);
    const checkOut = new Date(checkOutInput.value);

    if (!checkInInput.value || !checkOutInput.value) {
        totalPriceDisplay.textContent = '$0';
        return;
    }

    const nights = Math.ceil((checkOut - checkIn) / (1000 * 60 * 60 * 24));
    if (nights <= 0) {
        totalPriceDisplay.textContent = '$0';
        return;
    }

    const roomType = roomTypeSelect.value;
    const price = roomPrices[roomType];
    const total = nights * price;

    totalPriceDisplay.textContent = `$${total.toLocaleString()}`;

    // Update progress
    if (checkInInput.value && checkOutInput.value) {
        updateProgress(0);
    }
}

// Event listeners for booking form
checkInInput.addEventListener('change', () => {
    calculatePrice();
    // Set minimum checkout date
    checkOutInput.min = checkInInput.value;
});

checkOutInput.addEventListener('change', calculatePrice);
roomTypeSelect.addEventListener('change', calculatePrice);

// Booking form submission
bookingForm.addEventListener('submit', (e) => {
    e.preventDefault();
    alert(`Booking confirmed! Total: ${totalPriceDisplay.textContent}\nProceeding to payment...`);
});

/* ============================================
   ROOM CAROUSEL FUNCTIONALITY
   ============================================ */

const roomCarousels = document.querySelectorAll('.room-carousel');

roomCarousels.forEach((carousel) => {
    const track = carousel.querySelector('.room-carousel-track');
    const images = track.querySelectorAll('img');
    const prevBtn = carousel.querySelector('.room-carousel-btn.prev');
    const nextBtn = carousel.querySelector('.room-carousel-btn.next');
    let currentIndex = 0;

    function showImage(index) {
        if (index >= images.length) {
            currentIndex = 0;
        } else if (index < 0) {
            currentIndex = images.length - 1;
        } else {
            currentIndex = index;
        }

        track.style.transform = `translateX(-${currentIndex * 100}%)`;
    }

    prevBtn.addEventListener('click', () => showImage(currentIndex - 1));
    nextBtn.addEventListener('click', () => showImage(currentIndex + 1));
});

/* ============================================
   ROOM COMPARISON TABLE ANIMATIONS
   ============================================ */

const comparisonTable = document.querySelector('.comparison-table');
if (comparisonTable) {
    const rows = comparisonTable.querySelectorAll('tbody tr');
    rows.forEach((row, index) => {
        row.style.animation = `fadeInUp 0.5s ease-out forwards`;
        row.style.animationDelay = `${index * 0.1}s`;
    });
}

/* ============================================
   ROOM DETAIL BUTTONS
   ============================================ */

const roomButtons = document.querySelectorAll('.room-btn');
roomButtons.forEach((btn) => {
    btn.addEventListener('click', (e) => {
        const roomType = e.target.dataset.room;
        const roomNames = {
            standard: 'Standard Room',
            deluxe: 'Deluxe Room',
            suite: 'Executive Suite',
            penthouse: 'Presidential Penthouse'
        };
        alert(`Viewing details for ${roomNames[roomType]}...\nProceeding to detailed room view.`);
    });
});

/* ============================================
   AMENITIES SCROLL ANIMATION
   ============================================ */

const amenityCards = document.querySelectorAll('.amenity-card');

const observerOptions = {
    threshold: 0.2,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
        }
    });
}, observerOptions);

amenityCards.forEach((card) => {
    observer.observe(card);
});

/* ============================================
   CALENDAR FUNCTIONALITY
   ============================================ */

function generateCalendar() {
    const calendar = document.getElementById('calendar');
    if (!calendar) return;

    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth();

    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    calendar.innerHTML = '';

    // Day headers
    const dayHeaders = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    dayHeaders.forEach((day) => {
        const dayHeader = document.createElement('div');
        dayHeader.className = 'calendar-day';
        dayHeader.style.fontWeight = 'bold';
        dayHeader.style.background = '#333';
        dayHeader.style.color = 'white';
        dayHeader.textContent = day;
        calendar.appendChild(dayHeader);
    });

    // Empty cells before first day
    for (let i = 0; i < startingDayOfWeek; i++) {
        const emptyDay = document.createElement('div');
        emptyDay.style.background = 'transparent';
        calendar.appendChild(emptyDay);
    }

    // Days
    for (let day = 1; day <= daysInMonth; day++) {
        const dayDiv = document.createElement('div');
        dayDiv.className = 'calendar-day';
        dayDiv.textContent = day;

        dayDiv.addEventListener('click', () => {
            document.querySelectorAll('.calendar-day.selected').forEach((el) => {
                el.classList.remove('selected');
            });
            dayDiv.classList.add('selected');
        });

        calendar.appendChild(dayDiv);
    }
}

generateCalendar();

/* ============================================
   EVENT FORM
   ============================================ */

const eventForm = document.getElementById('eventForm');
if (eventForm) {
    eventForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(eventForm);
        alert('Event booking request submitted! Our team will contact you shortly to confirm details and pricing.');
        eventForm.reset();
    });
}

/* ============================================
   TESTIMONIALS CAROUSEL
   ============================================ */

let currentTestimonial = 0;
const testimonialCards = document.querySelectorAll('.testimonial-card');

function showTestimonial(n) {
    testimonialCards.forEach((card) => {
        card.classList.remove('active');
    });

    if (n >= testimonialCards.length) {
        currentTestimonial = 0;
    } else if (n < 0) {
        currentTestimonial = testimonialCards.length - 1;
    } else {
        currentTestimonial = n;
    }

    testimonialCards[currentTestimonial].classList.add('active');
}

const testimonialsCtrlNext = document.getElementById('testimonialsCtrlNext');
const testimonialsCtrlPrev = document.getElementById('testimonialsCtrlPrev');

if (testimonialsCtrlNext) {
    testimonialsCtrlNext.addEventListener('click', () => {
        showTestimonial(currentTestimonial + 1);
    });
}

if (testimonialsCtrlPrev) {
    testimonialsCtrlPrev.addEventListener('click', () => {
        showTestimonial(currentTestimonial - 1);
    });
}

// Auto-advance testimonials
setInterval(() => {
    showTestimonial(currentTestimonial + 1);
}, 6000);

/* ============================================
   CONTACT FORM
   ============================================ */

const contactForm = document.getElementById('contactForm');
if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const formData = new FormData(contactForm);
        alert(`Thank you for your message! We'll respond to ${formData.get('email')} shortly.`);
        contactForm.reset();
    });
}

/* ============================================
   MOBILE NAVIGATION
   ============================================ */

const hamburger = document.getElementById('hamburger');
const navMenu = document.querySelector('.nav-menu');

if (hamburger) {
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');

        // Animate hamburger
        hamburger.querySelectorAll('span').forEach((span, index) => {
            if (navMenu.classList.contains('active')) {
                if (index === 0) {
                    span.style.transform = 'rotate(45deg) translate(10px, 10px)';
                } else if (index === 1) {
                    span.style.opacity = '0';
                } else {
                    span.style.transform = 'rotate(-45deg) translate(8px, -8px)';
                }
            } else {
                span.style.transform = 'none';
                span.style.opacity = '1';
            }
        });
    });

    // Close menu when link is clicked
    navMenu.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            hamburger.querySelectorAll('span').forEach((span) => {
                span.style.transform = 'none';
                span.style.opacity = '1';
            });
        });
    });
}

/* ============================================
   SMOOTH SCROLLING
   ============================================ */

document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

/* ============================================
   INPUT FOCUS ANIMATIONS
   ============================================ */

const inputs = document.querySelectorAll('input, select, textarea');
inputs.forEach((input) => {
    input.addEventListener('focus', function () {
        this.style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.2)';
    });

    input.addEventListener('blur', function () {
        this.style.boxShadow = 'none';
    });
});

/* ============================================
   SCROLL ANIMATIONS
   ============================================ */

const animateOnScroll = () => {
    const elements = document.querySelectorAll('[class*="fade-in"], .room-card, .amenity-card');

    elements.forEach((element) => {
        const elementPosition = element.getBoundingClientRect().top;
        const screenPosition = window.innerHeight / 1.3;

        if (elementPosition < screenPosition) {
            element.style.opacity = '1';
            element.style.transform = 'translateY(0)';
        }
    });
};

window.addEventListener('scroll', animateOnScroll);

// Trigger on load
animateOnScroll();

/* ============================================
   FORM VALIDATION
   ============================================ */

const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

document.querySelectorAll('input[type="email"]').forEach((input) => {
    input.addEventListener('blur', function () {
        if (this.value && !validateEmail(this.value)) {
            this.style.borderColor = '#ff6b6b';
        } else {
            this.style.borderColor = '';
        }
    });
});

/* ============================================
   NEWSLETTER FORM
   ============================================ */

const newsletterForms = document.querySelectorAll('.newsletter-form');
newsletterForms.forEach((form) => {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = form.querySelector('input[type="email"]').value;
        alert(`Thank you for subscribing! A confirmation email has been sent to ${email}`);
        form.querySelector('input[type="email"]').value = '';
    });
});

/* ============================================
   ACCESSIBILITY - TAB NAVIGATION
   ============================================ */

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        navMenu?.classList.remove('active');
    }
});

/* ============================================
   DYNAMIC PRICING ON PAGE LOAD
   ============================================ */

// Set minimum date to today
const today = new Date().toISOString().split('T')[0];
if (checkInInput) {
    checkInInput.min = today;
    checkOutInput.min = today;
}
